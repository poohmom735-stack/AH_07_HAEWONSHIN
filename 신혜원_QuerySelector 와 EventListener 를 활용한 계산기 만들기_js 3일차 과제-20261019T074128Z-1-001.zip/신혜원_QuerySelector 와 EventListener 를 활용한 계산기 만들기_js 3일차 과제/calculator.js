const display = document.getElementById('display');
let currentFormula = "";
let isPowerOn = true;
let isCalculated = false;

// [보완] 페이지 로드 시 전원 버튼 스타일 설정 및 모든 버튼에 이벤트 연결
window.onload = function() {
    const onOffBtn = document.querySelector('.on-off');
    if (onOffBtn) onOffBtn.classList.add('on');
    
    // HTML의 모든 버튼을 찾아서 클릭 이벤트를 자동으로 연결합니다.
    const buttons = document.querySelectorAll('button');
    buttons.forEach(button => {
        button.addEventListener('click', handleButtonClick);
    });

    // 키보드 입력 이벤트 연결
    window.addEventListener('keydown', handleKeyboardInput);
};

// [추가] 버튼 클릭 시 클래스 종류에 따라 기존 함수들을 매칭해주는 핵심 핸들러
function handleButtonClick(e) {
    const target = e.target;
    const value = target.textContent.trim();

    // ON/OFF 버튼 처리
    if (target.classList.contains('on-off')) {
        togglePower();
        return;
    }

    // 전원이 꺼져 있으면 다른 버튼은 동작 안 함
    if (!isPowerOn) return;

    // 클래스명에 따라 기존 구현된 함수 호출
    if (target.classList.contains('clear')) {
        clearDisplay();
    } else if (target.classList.contains('enter')) {
        performCalculate();
    } else if (target.classList.contains('operator')) {
        appendOperator(value);
    } else if (target.classList.contains('number') || value === '.') {
        appendNumber(value);
    }
}

// [추가] 물리 키보드로도 계산기를 쓸 수 있게 해주는 기능
function handleKeyboardInput(e) {
    if (!isPowerOn) return;

    if (e.key >= '0' && e.key <= '9' || e.key === '.') {
        appendNumber(e.key);
    } else if (e.key === '+' || e.key === '-' || e.key === '*' || e.key === '/') {
        appendOperator(e.key);
    } else if (e.key === 'Enter' || e.key === '=') {
        e.preventDefault(); // 브라우저 기본 줄바꿈 방지
        performCalculate();
    } else if (e.key === 'Escape') {
        clearDisplay();
    }
}

function togglePower() {
    isPowerOn = !isPowerOn;
    const buttons = document.querySelectorAll('button:not(.on-off)');
    const onOffBtn = document.querySelector('.on-off');

    if (isPowerOn) {
        display.value = "0";
        display.style.backgroundColor = "#222";
        onOffBtn.classList.add('on');
        buttons.forEach(btn => btn.disabled = false);
    } else {
        display.value = "";
        display.style.backgroundColor = "#111";
        onOffBtn.classList.remove('on');
        buttons.forEach(btn => btn.disabled = true);
        currentFormula = "";
        isCalculated = false;
    }
}

function add(a, b) { return a + b; }
function subtract(a, b) { return a - b; }
function multiply(a, b) { return a * b; }
function divide(a, b) { return a / b; }

function appendNumber(number) {
    if (!isPowerOn) return;
    
    if (isCalculated) {
        display.value = "";
        currentFormula = "";
        isCalculated = false;
    }

    if (display.value === "0" || display.value === "Error" || display.value === "DivBy0") {
        display.value = number;
        currentFormula = number;
    } else {
        // 소수점(.) 연속 입력 방지 처리
        if (number === '.' && display.value.split(/[\s+\-*/]/).pop().includes('.')) return;
        
        display.value += number;
        currentFormula += number;
    }
}

function appendOperator(operator) {
    if (!isPowerOn) return;
    if (display.value === "Error" || display.value === "DivBy0") return;
    
    if (isCalculated) {
        isCalculated = false;
    }

    if (currentFormula === "") {
        currentFormula = "0";
    }

    if (currentFormula.endsWith(" ")) {
        currentFormula = currentFormula.slice(0, -3);
    }
    
    currentFormula += " " + operator + " ";
    display.value = currentFormula;
}

function clearDisplay() {
    if (!isPowerOn) return;
    display.value = "0";
    currentFormula = "";
    isCalculated = false;
}

function calculate(formula) {
    const tokens = formula.trim().split(/\s+/);
    if (tokens.length < 3 || tokens.length % 2 === 0) {
        return "Error";
    }

    const intermediateTokens = [];
    let i = 0;
    while (i < tokens.length) {
        const token = tokens[i];
        if (token === "*" || token === "/") {
            const left = Number(intermediateTokens.pop());
            const operator = token;
            const right = Number(tokens[i + 1]);

            if (isNaN(left) || isNaN(right)) return "Error";

            let res;
            if (operator === "*") {
                res = multiply(left, right);
            } else {
                if (right === 0) return "DivBy0";
                res = divide(left, right);
            }
            // 부동 소수점 오차 보정 추가 (소수점 10자리 제한)
            intermediateTokens.push(parseFloat(res.toFixed(10)));
            i += 2;
        } else {
            intermediateTokens.push(token);
            i++;
        }
    }

    let result = Number(intermediateTokens[0]);
    if (isNaN(result)) return "Error";

    for (let j = 1; j < intermediateTokens.length; j += 2) {
        const operator = intermediateTokens[j];
        const nextValue = Number(intermediateTokens[j + 1]);

        if (isNaN(nextValue)) return "Error";

        if (operator === "+") {
            result = add(result, nextValue);
        } else if (operator === "-") {
            result = subtract(result, nextValue);
        } else {
            return "Error";
        }
    }
    // 최종 결과 부동 소수점 오차 보정
    return parseFloat(result.toFixed(10));
}

function performCalculate() {
    if (!isPowerOn || !currentFormula) return;
    
    if (currentFormula.endsWith(" ")) {
        currentFormula = currentFormula.trim();
    }

    const result = calculate(currentFormula);
    display.value = result;
    isCalculated = true;
    
    if (result === "Error" || result === "DivBy0") {
        currentFormula = "";
    } else {
        currentFormula = result.toString();
    }
}

